from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))

from a1_a0_b_sim_runner import run_loop
from zip_communication_protocol import read_zip_packet


class TestA1PacketSource(unittest.TestCase):
    def test_packet_source_emits_request_when_inbox_empty(self) -> None:
        strategy_path = BASE / "a1_strategies" / "sample_strategy.json"
        run_id = "TEST_A1_PACKET_EMPTY"
        run_dir, _ = run_loop(
            strategy_path=strategy_path,
            steps=3,
            run_id=run_id,
            a1_source="packet",
            a1_model="",
            a1_timeout_sec=1,
            clean=True,
        )
        summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        self.assertEqual("A1_NEEDS_EXTERNAL_STRATEGY", summary["stop_reason"])
        packets = sorted((run_dir / "zip_packets").glob("*A1_STRATEGY_REQUEST.json"))
        self.assertTrue(packets)
        env = read_zip_packet(packets[0])
        self.assertEqual("A1_STRATEGY_REQUEST", env["kind"])


if __name__ == "__main__":
    unittest.main()

