# Workspace Layout v1
Status: DRAFT / NONCANON
Date: 2026-02-20

## Purpose
Keep the repo lean, predictable, and auditable.
Avoid document sprawl by constraining where new artifacts may be written.

## Top-Level Directories (Contract)
- `core_docs/`
  - User-authored core documents and imports.
  - Read-only during engineering runs (no generated artifacts).
- `system_v3/`
  - Current rewrite surface + tooling + runtime.
  - All new v3 artifacts must live here.
- `archive/`
  - Tiered archive surface (no live runtime state).
  - Optional for bootstrap saves; explicit for full-history retention.

Legacy/reference materials are retained under:
- `archive/LEGACY_REFERENCE__READ_ONLY/`

## No-New-Roots Rule
No new top-level folders without an explicit naming + purpose decision.

## Allowed Write Targets (Default)
- `system_v3/specs/` (spec edits only)
- `system_v3/specs/reports/` (lint/audit reports)
- `system_v3/tools/` (tooling only)
- `system_v3/runtime/` (canonical runtime code; no generated run artifacts)
- `system_v3/a2_state/` (A2 persistent brain; fixed interface)
- `system_v3/a2_derived_indices_noncanonical/` (optional derived A2 helper indices; regenerable)
- `system_v3/runs/` (controlled run surfaces; append-only + shard)
- `system_v3/runs/_run_templates_v1/` (immutable run template assets)
- `system_v3/conformance/` (versioned fixture packs + expected outcomes)
- `archive/` (tiered archive; no live runtime state)

## Save Profiles
Tool:
- `system_v3/tools/build_save_profile_zip.py`

Profiles:
- `bootstrap`:
  - includes `core_docs/` and `system_v3/`
  - excludes run artifacts (`system_v3/runs/`), archive trees (`archive/`), and nested archive files (`*.zip`, `*.tar*`, `*.7z`)
- `debug`:
  - includes `core_docs/` and `system_v3/`
  - includes only selected run IDs from `system_v3/runs/<RUN_ID>/`
  - excludes legacy migration bucket (`system_v3/runs/LEGACY__MIGRATED__/`)

Output:
- deterministic ZIP with fixed timestamps and lexicographic ordering
- embedded `SYSTEM_SAVE_PROFILE_MANIFEST_v1.json`
- companion `<zip>.sha256` file

## Archive Tiers
- `archive/CACHE__HIGH_ENTROPY__RECENT__PURGEABLE/`
  - short-lived exports, intermediate bundles, purge candidates.
- `archive/DEEP_ARCHIVE__LOW_ENTROPY__MILESTONES_ONLY/`
  - milestone snapshots, migrated legacy run heat, long-retained artifacts.
- `archive/LEGACY_REFERENCE__READ_ONLY/`
  - moved legacy packs/docs preserved for reference only.
